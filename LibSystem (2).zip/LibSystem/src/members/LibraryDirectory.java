package members;
import java.io.*; // New import for File I/O
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class LibraryDirectory {
    // File path where member data will be saved
    private static final String MEMBER_FILE = "library_members.ser";

    private List<Member> members; 
    private final Scanner scanner;
    
    // ScheduledExecutorService is used to run the background task periodically
    private final ScheduledExecutorService scheduler;

    public LibraryDirectory() {
        this.members = loadMembers(); 
        this.scanner = new Scanner(System.in);
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    
    @SuppressWarnings("unchecked")
    private List<Member> loadMembers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(MEMBER_FILE))) {
            System.out.println("[SYSTEM] Loading members from " + MEMBER_FILE + "...");
            // Read the entire list object from the file
            return (List<Member>) ois.readObject();
        } catch (FileNotFoundException e) {
            // File doesn't exist yet (first run), return an empty list.
            System.out.println("[SYSTEM] Member file not found. Starting with an empty directory.");
            return new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            // Error reading file or class mismatch, print error and start empty.
            System.err.println("[SYSTEM ERROR] Could not load members: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private void saveMembers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(MEMBER_FILE))) {
            // Write the entire list object to the file
            oos.writeObject(members);
            System.out.println("[SYSTEM] Members successfully saved to " + MEMBER_FILE);
        } catch (IOException e) {
            System.err.println("[SYSTEM ERROR] Could not save members: " + e.getMessage());
        }
    }
    
    // --- Core Directory Management Methods ---
    public void addMember() {
        System.out.println("\n--- Add New Member ---");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter phone number: ");
        String phone = scanner.nextLine();

        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        Member newMember = new Member(name, phone, address);
        members.add(newMember);
        System.out.println("\nSUCCESS: Member '" + name + "' added to the directory.");
    }

 
    public void removeMember() {
        System.out.println("\n--- Remove Member ---");
        if (members.isEmpty()) {
            System.out.println("The directory is currently empty.");
            return;
        }

        System.out.print("Enter the name of the member to remove: ");
        String nameToRemove = scanner.nextLine().trim();

        boolean removed = members.removeIf(member -> member.getName().equalsIgnoreCase(nameToRemove));

        if (removed) {
            System.out.println("SUCCESS: Member '" + nameToRemove + "' removed.");
        } else {
            System.out.println("ERROR: Member with name '" + nameToRemove + "' not found.");
        }
    }

    public void displayDirectory() {
        System.out.println("\n==================================");
        System.out.println("       LIBRARY MEMBER DIRECTORY   ");
        System.out.println("==================================");
        if (members.isEmpty()) {
            System.out.println("The directory is empty. Add members using option 1.");
        } else {
            for (Member member : members) {
                System.out.println(member);
            }
        }
        System.out.println("==================================");
    }
    
    public void updateRenewalStatus() {
        System.out.println("\n--- Update Book Status (Check-out/Return) ---");
        System.out.print("Enter the name of the member: ");
        String name = scanner.nextLine().trim();
        
        // Find the member
        Member memberToUpdate = members.stream()
            .filter(m -> m.getName().equalsIgnoreCase(name))
            .findFirst()
            .orElse(null);

        if (memberToUpdate == null) {
            System.out.println("Member not found.");
            return;
        }

        // Display current status, including book title if checked out
        String currentStatus;
        if (memberToUpdate.getDueDate() == null) {
            currentStatus = "No book out";
        } else {
            currentStatus = "Book: '" + memberToUpdate.getBookTitle() + "' due on " + memberToUpdate.getDueDate();
        }

        System.out.println("Current status for " + memberToUpdate.getName() + ": " + currentStatus);
        System.out.println("Choose action: (1) Check-out/Renew | (2) Return Book");
        System.out.print("Enter choice (1 or 2): ");
        String choice = scanner.nextLine();
        
        if (choice.equals("1")) {
            // Prompt for book title
            System.out.print("Enter the **title of the book**: ");
            String title = scanner.nextLine();
            
            System.out.print("Enter days until due date (e.g., 14 for two weeks): ");
            try {
                int days = Integer.parseInt(scanner.nextLine());
                // Call the correct setDueDate method with both title and days
                memberToUpdate.setDueDate(title, days);
            } catch (NumberFormatException e) {
                System.out.println("Invalid number entered. Status update failed.");
            }
        } else if (choice.equals("2")) {
            memberToUpdate.returnBook(name);
        } else {
            System.out.println("Invalid choice.");
        }
    }


    // --- Background Feature: Due Date Checker Thread ---
    private class DueDateChecker implements Runnable {
        private final int[] ALERT_DAYS = {10, 7, 5, 3, 2, 1}; // Specific days before the due date we want to send an alert

        @Override
        public void run() {
            LocalDate today = LocalDate.now();
            
            System.out.println("\n[BACKGROUND CHECKER] Checking for books due on specific upcoming dates...");

            // Synchronize to prevent conflicts with the main thread modifying the list
            synchronized (members) {
                for (Member member : members) {
                    LocalDate dueDate = member.getDueDate();
                    
                    if (dueDate != null) {
                        for (int days : ALERT_DAYS) {
                            // Calculate the date that is 'days' away from today
                            LocalDate alertDate = today.plusDays(days);
                            
                            
                            if (dueDate.isEqual(alertDate)) {
                                
                                // Print an alert to the console
                                System.out.println("\n*************************************************");
                                System.out.println("!!! URGENT ALERT: Book Due Date Reminder !!!");
                                System.out.println("Member: " + member.getName());
                                
                                // Now correctly displays the book title
                                System.out.println("Book Title: '" + member.getBookTitle() + "'"); 
                                System.out.println("ALERT: Book is due in **" + days + " days** on " + dueDate);
                                System.out.println("Contact: " + member.getPhoneNumber());
                                System.out.println("*************************************************\n");
                            }
                        }
                    }
                }
            }
        }
    }

    public void startBackgroundChecker() {
        // Schedule the DueDateChecker task to run every 24 hours (1 day), starting immediately (0 delay).
        scheduler.scheduleAtFixedRate(new DueDateChecker(), 0, 24, TimeUnit.HOURS);
        System.out.println("[SYSTEM] Background Due Date Checker started. Running once every 24 hours...");
    }

    public void stopBackgroundChecker() {
        scheduler.shutdown();
        System.out.println("[SYSTEM] Due Date Checker stopped.");
    }

    // --- Main Application Loop ---

    public void run() {
        // Start the background process immediately
        startBackgroundChecker(); 
        
        boolean running = true;
        while (running) {
            displayMenu();
            String choice = scanner.nextLine();

            switch (choice.trim()) {
                case "1":
                    addMember();
                    break;
                case "2":
                    removeMember();
                    break;
                case "3":
                    displayDirectory();
                    break;
                case "4":
                    updateRenewalStatus();
                    break;
                case "5":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
            // Add a small pause to make the output cleaner
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        saveMembers(); 
        
        // Clean up the background thread before exiting
        stopBackgroundChecker();
        scanner.close();
        System.out.println("Library Directory application closed.");
    }

    private void displayMenu() {
        System.out.println("\n--- Library Member Directory Menu ---");
        System.out.println("1. Add a New Member");
        System.out.println("2. Remove a Member");
        System.out.println("3. View All Members");
        System.out.println("4. Update Book Status (Check-out/Return)");
        System.out.println("5. Exit Application");
        System.out.print("Enter your choice: ");
    }

    public static void main(String[] args) {
        new LibraryDirectory().run();
    }
}