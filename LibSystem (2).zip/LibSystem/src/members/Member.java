package members;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

// --- CLASS 1: Member (Data Model) ---
public class Member {
    private final String memberId;
    private String name;
    private String phoneNumber;
    private String address;
    private boolean canRenew;
    
    // Stores Book Name -> Due Date
    private Map<String, LocalDate> checkedOutBooks;

    public Member(String name, String phoneNumber, String address) {
        this.memberId = UUID.randomUUID().toString().substring(0, 8); // Unique ID
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.canRenew = true; // Default to allowing renewal
        this.checkedOutBooks = new HashMap<>();
    }

    // Getters
    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress() { return address; }
    public boolean isCanRenew() { return canRenew; }
    public Map<String, LocalDate> getCheckedOutBooks() { return checkedOutBooks; }

    // Setters
    public void setCanRenew(boolean canRenew) { this.canRenew = canRenew; }
    
    // Business Logic Methods
    
    /** Checks out a book, setting the due date 3 weeks from now. */
    public void checkoutBook(String bookTitle) {
        // Default loan period: 3 weeks (21 days)
        LocalDate dueDate = LocalDate.now().plusDays(21);
        checkedOutBooks.put(bookTitle, dueDate);
        System.out.printf("  > Book '%s' checked out. Due date: %s.\n", bookTitle, dueDate);
    }

    /** Returns a book. */
    public boolean returnBook(String bookTitle) {
        if (checkedOutBooks.containsKey(bookTitle)) {
            checkedOutBooks.remove(bookTitle);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        String booksString = checkedOutBooks.isEmpty() ? "None" : checkedOutBooks.keySet().toString();
        return String.format("ID: %s | Name: %s | Phone: %s | Address: %s | Renewal Status: %s | Books: %s",
            memberId, name, phoneNumber, address, canRenew ? "Allowed" : "Blocked", booksString);
    }

	public String getBookTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	public LocalDate getDueDate() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDueDate(String title, int days) {
		// TODO Auto-generated method stub
		
	}

}