package members;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Map;

public class MemberManager {
    public MemberManager() {
    }
    // The constructor is now empty as data is held by the LibraryManager singleton.
    
    
    public Member findMember(String memberId) {
        return LibraryManager.getInstance().getMemberRegistry().get(memberId);
    }
    
    
    public void addMember(Member member) {
        LibraryManager.getInstance().getMemberRegistry().put(member.getMemberId(), member);
        System.out.println("--- Member Added Successfully ---");
        System.out.println("New Member ID: " + member.getMemberId());
        LibraryManager.getInstance().saveData(); // Central save call
    }

   
    public boolean removeMember(String memberId) {
        Map<String, Member> members = LibraryManager.getInstance().getMemberRegistry();
        Member member = findMember(memberId);
        
        if (member != null) {
            if (!member.getCheckedOutBooks().isEmpty()) {
                System.out.println("!!! ERROR: Member has books checked out and cannot be removed.");
                return false;
            }
            members.remove(memberId);
            System.out.println("--- Member ID " + memberId + " successfully removed. ---");
            LibraryManager.getInstance().saveData(); // Central save call
            return true;
        }
        System.out.println("!!! ERROR: Member ID not found.");
        return false;
    }
    
    public void checkoutBook(String memberId, String bookTitle) {
        Member member = findMember(memberId);
        if (member == null) {
            System.out.println("!!! ERROR: Member ID not found.");
            return;
        }
        if (!member.isCanRenew()) {
            System.out.println("!!! ALERT: This member's renewal status is currently Blocked.");
        }
        member.checkoutBook(bookTitle);
        LibraryManager.getInstance().saveData(); // Central save call
    }
    
    public void returnBook(String memberId, String bookTitle) {
        Member member = findMember(memberId);
        if (member == null) {
            System.out.println("!!! ERROR: Member ID not found.");
            return;
        }
        if (member.returnBook(bookTitle)) {
            System.out.printf("--- Book '%s' successfully returned by %s. ---\n", bookTitle, member.getName());
            LibraryManager.getInstance().saveData(); // Central save call
        } else {
            System.out.printf("!!! ERROR: Book '%s' was not checked out by %s.\n", bookTitle, member.getName());
        }
    }

    public void checkDueDatesAndAlert() {
        System.out.println("\n===== RUNNING BACKGROUND DUE DATE CHECKER =====");
        LocalDate today = LocalDate.now();
        int alertThresholdDays = 3;
        boolean foundAlerts = false;
        
        Map<String, Member> members = LibraryManager.getInstance().getMemberRegistry();

        for (Member member : members.values()) {
            for (Map.Entry<String, LocalDate> entry : member.getCheckedOutBooks().entrySet()) {
                String book = entry.getKey();
                LocalDate dueDate = entry.getValue();
                
                long daysUntilDue = ChronoUnit.DAYS.between(today, dueDate);

                if (daysUntilDue < 0) {
                    System.out.printf("!!! OVERDUE ALERT: %s (%s) - Book: '%s' is %d days overdue!\n", 
                        member.getName(), member.getMemberId(), book, Math.abs(daysUntilDue));
                    foundAlerts = true;
                } else if (daysUntilDue <= alertThresholdDays) {
                    System.out.printf("--- UPCOMING ALERT: %s (%s) - Book: '%s' is due in %d days (%s).\n", 
                        member.getName(), member.getMemberId(), book, daysUntilDue, dueDate);
                    foundAlerts = true;
                }
            }
        }
        
        if (!foundAlerts) {
            System.out.println("No immediate due date or overdue alerts found.");
        }
        System.out.println("=============================================\n");
    }

    /** Prints a list of all members from the central registry. */
    public void displayAllMembers() {
        Map<String, Member> members = LibraryManager.getInstance().getMemberRegistry();
        
        System.out.println("\n===== CURRENT MEMBERS IN DIRECTORY =====");
        if (members.isEmpty()) {
            System.out.println("The directory is empty. Please add a member using option 1.");
        } else {
            for (Member member : members.values()) {
                System.out.println(member);
            }
        }
        System.out.println("========================================\n");
    }
}
